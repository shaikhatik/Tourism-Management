﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Addpackage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (Page.IsPostBack == false)
        {

        }   
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);


        FileUpload1.SaveAs(Server.MapPath("~/photo/") + FileUpload1.FileName);


        con.Open();
        SqlCommand cmd = new SqlCommand("Insert into package (Id,pname,adults,childrens,description,stayamt,travelname,travelamt,days,nights,image)values('" + txtpid.Text + "','" + txtplacename.Text + "','" + Convert.ToDouble(txtnoadults.Text) + "','" + Convert.ToDouble(txtnoofchild.Text) + "','" + txtdesc.Text + "','" + Convert.ToDouble(txtstayamt.Text) + "','" + txttravelname.Text + "','" + Convert.ToDouble(txttravelamt.Text) + "','" + Dropnodays.SelectedItem.Text + "','" + Dropnonight.SelectedItem.Text + "','" + "~/photo/" + FileUpload1.FileName + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        txtpid.Text = "";
        txtplacename.Text = "";
        txtnoadults.Text = "";
        txtnoofchild.Text = "";
        txtdesc.Text = "";
        txtstayamt.Text = "";
        txttravelamt.Text = "";
        txttravelname.Text = "";
        Dropnodays.SelectedIndex = 0;
        Dropnonight.SelectedIndex = 0;
        lblmsg.Text = "Package Added Successfully";

    }
}




 
