﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_Checkout : System.Web.UI.Page
{
    bool isTrue = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {

                lblpayment.Text = "9999";
            
    
                    }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        DataRow dr;
        dt.Columns.Add("id");
        dt.Columns.Add("pname");
        dt.Columns.Add("stayamt");
        dt.Columns.Add("travelamt");
        dt.Columns.Add("totalamt");


        if (Request.QueryString["Id"] != null)
        {
            if (Session["booking"] == null)
            {

                dr = dt.NewRow();
                string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
                SqlConnection con = new SqlConnection(connStr);
                SqlDataAdapter da = new SqlDataAdapter("select * from package where Id=" + Request.QueryString["Id"], con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dr["Id"] = ds.Tables[0].Rows[0]["Id"].ToString();
                dr["pname"] = ds.Tables[0].Rows[0]["pname"].ToString();
                dr["stayamt"] = ds.Tables[0].Rows[0]["stayamt"].ToString();
                dr["travelamt"] = ds.Tables[0].Rows[0]["travelamt"].ToString();
           
                dt.Rows.Add(dr);
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into bookingdetails(Id,Email,pname,stayamt,travelamt,totalamt) values('" + dr["Id"] + "','" + Session["username"] + "','" + dr["pname"] + "','" + dr["stayamt"] + "','" + dr["travelamt"] + "','" + dr["totalamt"] + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                
                Session["booking"] = dt;
                //GridView1.FooterRow.Cells[4].Text = "Total Amount";
                Response.Redirect("Viewplaces.aspx");

            }
            else
            {
                dt = (DataTable)Session["booking"];
                dr = dt.NewRow();
                string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
                SqlConnection con = new SqlConnection(connStr);
                SqlDataAdapter da = new SqlDataAdapter("select * from package where Id=" + Request.QueryString["Id"], con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dr["Id"] = ds.Tables[0].Rows[0]["Id"].ToString();
                dr["pname"] = ds.Tables[0].Rows[0]["pname"].ToString();
                dr["stayamt"] = ds.Tables[0].Rows[0]["stayamt"].ToString();
                dr["travelamt"] = ds.Tables[0].Rows[0]["travelamt"].ToString();
                dt.Rows.Add(dr);
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into bookingdetails(Id,Email,pname,stayamt,travelamt,totalamt) values('" + dr["Id"] + "','" + Session["username"] + "','" + dr["pname"] + "','" + dr["stayamt"] + "','" + dr["travelamt"] + "','" + dr["totalamt"] + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Payment();
                Session["booking"] = dt;
                //GridView1.FooterRow.Cells[4].Text = "Total Amount";
                Response.Redirect("ViewPlaces.aspx");
            }
        }
        
        
    }

    public void Payment()
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        if (isTrue == true)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" Insert into PaymentMst (Uname,Amount,Type,Bank,Branch,CardNo,CCV,EntryDate) values('" + Session["username"].ToString() + "','" + Convert.ToDouble(lblpayment.Text) + "','" + DropDownList1.SelectedItem.Text + "','" + drpbankname.SelectedItem.Text + "','" + drpbranch.SelectedItem.Text + "','" + txtcardno.Text + "','" + Convert.ToInt32(txtccv.Text) + "','" + System.DateTime.Now + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }

    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex == 0)
        {
            lbl.Text = "Select Payment Option";
            btncash.Visible = false;
            Panel1.Visible = false;
        }
        else if (DropDownList1.SelectedIndex == 1 || DropDownList1.SelectedIndex == 2)
        {
            btncash.Visible = false;
            Panel1.Visible = true;
        }
        else if (DropDownList1.SelectedIndex == 3)
        {
            Panel1.Visible = false;
            btncash.Visible = true;
        }
    }
    protected void btncash_Click(object sender, EventArgs e)
    {

        Response.Redirect("Thanks.aspx");

    }
}