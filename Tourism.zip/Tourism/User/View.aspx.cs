﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class User_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbleror.Text = "";

        if (Page.IsPostBack == false)
        {


            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);
            string id = Request.QueryString["Id"].ToString();
            string sql = "SELECT * FROM package where Id = '" + id + "' ";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandText = sql;
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            lblplacename.Text = dt.Rows[0]["pname"].ToString();
            lblstayrs.Text = dt.Rows[0]["stayamt"].ToString();
            lblday.Text = dt.Rows[0]["days"].ToString();
            lblnight.Text = dt.Rows[0]["nights"].ToString();
            Image3.ImageUrl = dt.Rows[0]["image"].ToString();
            lbldetil.Text = dt.Rows[0]["description"].ToString();
            lbladults.Text = dt.Rows[0]["adults"].ToString();
            lblchilds.Text = dt.Rows[0]["childrens"].ToString();
            travelname.Text = dt.Rows[0]["travelname"].ToString();
            travelamt.Text = dt.Rows[0]["travelamt"].ToString();
            
            int stayamt = Convert.ToInt32(dt.Rows[0]["stayamt"].ToString());
            int travelam = Convert.ToInt16(dt.Rows[0]["travelamt"].ToString());
            int Totalprice = stayamt + travelam;
            totalamt.Text = Convert.ToString(Totalprice);

        }

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        {
            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);
            string id = Request.QueryString["Id"].ToString();
            string sql = "SELECT * FROM package where Id = '" + id + "' ";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandText = sql;
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            
            
            
            Response.Redirect("Checkout.aspx?id= '" + id + "'");
        }
    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        Response.Redirect("Checkout.aspx?id=" + e.CommandArgument.ToString());
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }



}
